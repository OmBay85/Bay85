<?php

// Your User-Agent
$uag = "xxxxxxxxx";


// Your Cookie
$cook = 'xxxxxxxxxxx';


// Timer On Website
$time= "80";
